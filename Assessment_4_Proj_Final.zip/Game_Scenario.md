GAME SCENARIO

STORYLINE:
Gilbert the adventurer is tasked with creating the perfect sandwich with
only the most pristine ingredients across the land.

locations:
1. Forest -> Clearing
2. Mountains -> Cave
3. village -> House
4. plains -> Wheat Field
5. volcano -> forge

Characters
1. Adventurer(Player)
2. Farmer
3. Forge Master
4. Gnome Miner
5. King Boar
6. Villager

items:
1. Meat
2. Minerals
3. Sword
4. Vegetables
5. Wheat
6. Cooking Tools
7. Shield
8. Key
9. money
10. Cheese




